
/**
 * Phaser canvas
 */
const myCustomCanvas = document.createElement('canvas');
myCustomCanvas.id = 'myCustomCanvas';
myCustomCanvas.style = 'border: 8px solid red';
document.body.appendChild(myCustomCanvas);

var config = {
    type: Phaser.CANVAS,
    width: 800,
    height: 600,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 200 }
        }
    },
    canvas: document.getElementById('myCustomCanvas'),
    scene: {
        preload: preload,
        create: create
    }
};

var game = new Phaser.Game(config);

function preload ()
{
    this.load.image('mario', 'assets/mario1.png');
    this.load.image('bichi', 'assets/mario3.png');
}

function create ()
{
    this.add.image(400, 300, 'bichi');
    let box = this.add.container(50, 50);

    let mario = this.add.sprite(20,20,'mario',1);
    mario.setScale(0.5);
    box.add(mario);

}




/**
 * PIXI 
 */
 let app = new PIXI.Application({width: 600, height: 600});
 document.body.appendChild(app.view);


 let container = new PIXI.Container() //創建容器
 let sprite=new PIXI.Sprite.fromImage('assets/mario2.png') //載入圖片

 app.stage.addChild(container) //先將container放入根container stage
 container.addChild(sprite) //再把圖片物件放入container
 container.interactive = true // 設定為可互動
 container.buttonMode = true  // pointer: cursor
 container.x=100 //設定container x座標
 container.y=100 //設定container y座標
 
 // 監聽事件
 container.on('mouseover', function(){
     //滑鼠移過變半透明
     container.alpha=.5
 });
 container.on('mouseout', function(){
     //滑鼠移出變回不透明
     container.alpha=1
 });
 